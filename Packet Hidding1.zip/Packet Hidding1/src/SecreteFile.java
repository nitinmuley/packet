import java.io.*;
public class SecreteFile {
	public static void main(String[] args)
	{
		int a;
		try 
		{
			byte[] b;
			FileInputStream fin=new FileInputStream("secret.dat");
			b=new byte[(int)fin.available()];
			fin.read(b);
			for(a=0;a<b.length;a++)
			{
				System.out.print((char)b[a]);
			}
		} catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
