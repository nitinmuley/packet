
package com.mycompany.logic;


import java.io.Serializable;

public class MultiCastString implements Serializable {
	String multiStr = "";

}
