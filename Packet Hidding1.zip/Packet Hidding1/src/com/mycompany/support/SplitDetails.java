package com.mycompany.support;

public class SplitDetails {
	public String[] split(String text) {
		String[] splitString = text.split(":");
		return splitString;
	}

}
