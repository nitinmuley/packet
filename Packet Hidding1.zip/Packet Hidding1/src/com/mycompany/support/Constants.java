package com.mycompany.support;



public class Constants {
	public static String cphs = "All Or Nothing Transformations";
	public static String crypt = "Cryptographic Puzzles";
	public static String shcs = "Strong Hiding Commitment Scheme";
	public static String INTER="inter";
	public static String SERVER="server";
	
}
