package com.mycompany.valueobject;

import java.util.TreeMap;

public class MobilityValueObject {
	private int mobilityScore;

	public int getMobilityScore() {
		return mobilityScore;
	}

	public void setMobilityScore(int mobilityScore) {
		this.mobilityScore = mobilityScore;
	}

}
